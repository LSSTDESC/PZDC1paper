Hello editors,
   Several comments that were included in bold have been changed to italic font instead.  This is for purposeful emphasis, and is not a remnant of revision highlighting.  Also, as noted in the "Details and Comments" cover letter, we wish to have "The LSST Dark Energy Science Collaboration" listed as the final author in the final listing.  This is already present in the LaTex files, but there did not seem to be an easy way to include the full Collaboration in the Step 5: Authors & Institutions email-based system.  So, please add "and The LSST Dark Energy Science Collaboration" to the end of the author list such that it is visible on the MNRAS website and such.  An example of another paper from our collaboration with such an inclusion is here: https://academic.oup.com/mnras/article-abstract/495/4/5040/5850379?redirectedFrom=fulltext

Thanks,
Sam Schmidt and Alex Malz
